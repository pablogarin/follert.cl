<?php
include_once 'common.php';
include_once 'connect.php';

$view = new View();
$view->setFolder(PATH."/templates/");

if( isset($_REQUEST['p']) ){
    $page = $_REQUEST['p'];
} else {
    $page = null;
}
$view->set("current",$page);
switch( $page ){
    case 'productos':
        $cur = $dbh->query("select * from producto;");
        if( isset($cur[0]) ){
            $productos = $cur;
            $view->set("productos",$productos);
        }
        if( isset($_REQUEST['id']) ){
            $id = $_REQUEST['id'];
            $cur = $dbh->query("select * from producto where id=?;",array($id));
            $view->set("title",$cur[0]['nombre']);
            if( isset($cur[0]) ){
                foreach( $cur[0] as $llave=>$valor ){
                    $view->set($llave,$valor);
                }
            }
        } else {
            $id = $productos[0]['id'];
            $view->set("title",$productos[0]['nombre']);
            foreach( $productos[0] as $llave=>$valor ){
                $view->set($llave,$valor);
            }
        }
        if( isset($id) ){
            $view->set("id_producto",$id);
        }
        $template = "productos.html";
        break;
    case 'servicios':
        $cur = $dbh->query("select * from servicio;");
        if( isset($cur[0]) ){
            $servicios = $cur;
            $view->set("servicios",$servicios);
        }
        if( isset($_REQUEST['id']) ){
            $id = $_REQUEST['id'];
            $cur = $dbh->query("select * from servicio where id=?;",array($id));
            $view->set("title",$cur[0]['nombre']);
            if( isset($cur[0]) ){
                foreach( $cur[0] as $llave=>$valor ){
                    $view->set($llave,$valor);
                }
            }
        } else {
            $id = $servicios[0]['id'];
            $view->set("title",$servicios[0]['nombre']);
            foreach( $servicios[0] as $llave=>$valor ){
                $view->set($llave,$valor);
            }
        }
        if( isset($id) ){
            $view->set("id_servicio",$id);
        }
        $template = "servicios.html";
        break;
    case 'quienes-somos':
        $view->set("title","Quienes Somos");
        $cur = $dbh->query("select * from texto where id=2;");
        $view->set("descripcion",$cur[0]['cuerpo']);
        $cur = $dbh->query("select * from configs where id=2;");
        $video = $cur[0]['valor'];
        if(strstr($_SERVER['HTTP_USER_AGENT'],'iPhone') || strstr($_SERVER['HTTP_USER_AGENT'],'iPod')){
            $video = preg_replace('/width="[0-9]+"/',"width='290px'",$video);
            $video = preg_replace('/height="[0-9]+"/',"height='100%'",$video);
        } else {
            $video = preg_replace('/width="[0-9]+"/',"width='100%'",$video);
            $video = preg_replace('/height="[0-9]+"/',"height='300px'",$video);
        }
        $view->set("video",$video);
        $template = "about.html";
        break;
    case 'contacto':
        $view->set("title","Contacto");
        $template = "contacto.html";
        break;
    case '':
    case null:
    default:
        $view->set("title","Home");
        $cur = $dbh->query("select * from banner;");
        if( isset($cur[0]) ){
            $view->set("banners",$cur);
        }
        $cur = $dbh->query("select * from frase;");
        if( isset($cur[0]) ){
            $view->set("frases",$cur);
        }
        $template = "home.html";
        break;
}
if( isset($template) ){
    $view->setTemplate($template);
    $view->set("content",$view->getView());
}

$view->setTemplate("index.html");
print $view->getView();
?>
