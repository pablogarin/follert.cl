<?php
if( isset( $_REQUEST['grabar'] ) ){
    $obj = new Producto($dbh);
    $obj->setNew(!isset($_REQUEST['id']));
    $obj->setValues($_REQUEST);
    header("Location: /admin/productos");
}
if( isset($_REQUEST['eliminar']) ){
    $dbh->query("delete from producto where id=?;",array($_REQUEST['eliminar']));
    header("Location: /admin/productos");
}
if( isset($_REQUEST['edit']) ){
    $id = $_REQUEST['edit'];
    $cur = $dbh->query("select * from producto where id=?;",array($id));
    if( isset($cur[0]) ){
        foreach( $cur[0] as $llave=>$valor ){
            $view->set($llave,$valor);
        }
    }
}
$cur = $dbh->query("select * from producto;");
if( isset($cur[0]) ){
    $view->set("productos",$cur);
}

$view->setTemplate("productos.html");
$content = $view->getView();

