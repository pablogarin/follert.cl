<?php
if( isset( $_REQUEST['grabar'] ) ){
    if( isset($_REQUEST['banners']) ){
        foreach( $_REQUEST['banners'] as $value ){
            $data = array();
            $ban = new Banner($dbh);
            $ban->setNew(true);
            $data['grabar'] = 1;
            $data['foto'] = $value;
            $ban->setValues($data);
        }
    }
    if( isset($_REQUEST['frases']) ){
        foreach( $_REQUEST['frases']['nuevo'] as $value ){
            $data = array();
            $obj = new Frase($dbh);
            $obj->setNew(true);
            $data['grabar'] = 1;
            $data['frase'] = $value;
            $obj->setValues($data);
        }
        foreach( $_REQUEST['frases'] as $id=>$value ){
            $data = array();
            $obj = new Frase($dbh);
            $obj->setNew(false);
            $data['grabar'] = 1;
            $data['frase'] = $value;
            $data['id'] = $id;
            $obj->setValues($data);
        }
    }
    header("Location: /admin/home");
}
if( isset($_REQUEST['eliminar']) ){
    if( isset($_REQUEST['eliminar']['banner']) ){
        $dbh->query("delete from banner where id=?;",array($_REQUEST['eliminar']['banner']));
    }
    if( isset($_REQUEST['eliminar']['frase']) ){
        $dbh->query("delete from frase where id=?;",array($_REQUEST['eliminar']['frase']));
    }
}
$cur = $dbh->query("select * from banner;");
if( isset($cur[0]) ){
    $view->set("banners",$cur);
}
$cur = $dbh->query("select * from frase;");
if( isset($cur[0]) ){
    $view->set("frases",$cur);
}

$view->setTemplate("home.html");
$content = $view->getView();
