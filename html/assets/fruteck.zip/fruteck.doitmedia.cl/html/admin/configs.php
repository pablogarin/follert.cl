<?php
if( isset($_REQUEST['grabar']) ){
    if( isset($_REQUEST['configs']) ){
        foreach( $_REQUEST['configs'] as $k=>$v ){
            $data = $v;
            $data['id'] = $k;
            $data['grabar'] = 1;
            $conf = new Configuracion($dbh);
            $conf->setNew(false);
            $conf->setValues($data);
        }
        header("Location: /admin/configuraciones");
    }
}
$cur = $dbh->query("select * from configs;");
$view->set("configs", $cur);

$view->setTemplate("configs.html");
$content = $view->getView();
