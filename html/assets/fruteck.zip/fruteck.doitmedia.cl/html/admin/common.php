<?php
error_reporting(E_ALL);
ini_set('display_errors',True);
include_once '../common.php';

$view = new View();
$view->setFolder(PATH."/html/admin/templates");
