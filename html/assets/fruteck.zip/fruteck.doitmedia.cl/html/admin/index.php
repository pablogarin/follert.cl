<?php
include_once 'common.php';
include_once 'session.php';
include_once 'model.php';

// seccion actual
$current = $_SERVER['SCRIPT_URL'];
$current = str_replace("/admin/","",$current);
$current = str_replace("/","",$current);

// secciones del menu
$navs = array(
    'home' => array(
        'url' => 'home',
        'name' => 'Home',
        'current' => $current=='home'
    ),
    'productos' => array(
        'url' => 'productos',
        'name' => 'Productos',
        'current' => $current=='productos'
    ),
    'servicios' => array(
        'url' => 'servicios',
        'name' => 'Servicios',
        'current' => $current=='servicios'
    ),
    'textos' => array(
        'url' => 'textos',
        'name' => 'Textos',
        'current' => $current=='textos'
    ),
    'configuraciones' => array(
        'url' => 'configuraciones',
        'name' => 'Configuraciones',
        'current' => $current=='configuraciones'
    )
);
$view->set("navs",$navs);
//*
if( isset($_FILES) ){
    foreach( $_FILES  as $file ){
        $name = $file['name'];
        $filepath = PATH."/html/assets/".$name;
        if( !move_uploaded_file($file['tmp_name'],$filepath) ){
            error_log("No se pudo subir el archivo '".$name."'");
        }
    }
}
//*/
switch( $current ){
    case 'home':
        include_once 'home.php';
        break;
    case 'productos':
        include_once 'productos.php';
        break;
    case 'servicios':
        include_once 'servicios.php';
        break;
    case 'textos':
        include_once 'textos.php';
        break;
    case 'configuraciones':
        include_once 'configs.php';
        break;
}
if( isset($content) ){
    $view->set("CONTENT",$content);
}
$view->setTemplate("index.html");
print $view->getView();
?>
