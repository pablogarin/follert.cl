<?php
if( isset( $_REQUEST['grabar'] ) ){
    $obj = new Servicio($dbh);
    $obj->setNew(!isset($_REQUEST['id']));
    $obj->setValues($_REQUEST);
    header("Location: /admin/servicios");
}
if( isset($_REQUEST['eliminar']) ){
    $dbh->query("delete from servicio where id=?;",array($_REQUEST['eliminar']));
    header("Location: /admin/servicios");
}
if( isset($_REQUEST['edit']) ){
    $id = $_REQUEST['edit'];
    $cur = $dbh->query("select * from servicio where id=?;",array($id));
    if( isset($cur[0]) ){
        foreach( $cur[0] as $llave=>$valor ){
            $view->set($llave,$valor);
        }
    }
}
$cur = $dbh->query("select * from servicio;");
if( isset($cur[0]) ){
    $view->set("servicios",$cur);
}

$view->setTemplate("servicios.html");
$content = $view->getView();

