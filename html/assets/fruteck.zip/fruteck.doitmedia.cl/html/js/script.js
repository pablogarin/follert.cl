/*
 * Script sitio Frutek
 * */
var url = "http://frutek.doitmedia.cl"
$(document).ready(function(evt){
    loadEvents();
});
var slideFrase;
function loadEvents(){
    // ALL EVENTS
    $("nav#main-nav > ul > li > a").on("click",function(){
        $("nav#main-nav > ul > li").removeClass("active");
        $(this).parents("li:first").addClass("active");
    });
    $("#banners-home").slick({
        dots: false,
        infinite: true,
        autoplay: true,
        autoplaySpeed: 5000,
        slidesToShow: 1,
        slidesToScroll: 1,
        prevArrow:"#banner-home .slider-prev",
        nextArrow:"#banner-home .slider-next",
        fade: true,
        cssEase: 'linear'
    });
    slideFrase = setInterval(function(){
        var active = $("#frases-slide div:first").clone();
        active.removeClass('active');
        active.css({'display':'none'});
        $("#frases-slide div:first").fadeOut(666,function(){ 
            $(this).remove();
        });
        $("#frases-slide div:nth-child(2)").fadeIn(666,function(){
            $(this).addClass('active');
        });
        $("#frases-slide").append(active);
    },3000);
    /*
    $("#frases-slide").slick({
        dots: false,
        infinite: true,
        autoplay: true,
        autoplaySpeed: 3000,
        slidesToShow: 1,
        slidesToScroll: 1,
        prevArrow:"#banner-home .slider-prev",
        nextArrow:"#banner-home .slider-next",
        fade: true,
        cssEase: 'linear'
    });
    //*/
    $("form[name='contacto']").on("submit",function(evt){
        evt.preventDefault();
        var data = $("form[name='contacto']").serialize();
        $.ajax({
            url     : '/ajax/send.php',
            method  : 'POST',
            data    : data,
            success : function(resp){
                alert(resp);
            }
        }).done(function(){
            $("form[name='contacto']")[0].reset();
        });
    });
}
